a = [0,0,0,0]
aa = []
aa.append(a)
a = []
a = [0,0,0,1]
aa.append(a)
print(aa)
